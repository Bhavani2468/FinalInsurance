package com.insurance.insuranceCompany.rowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.insurance.insuranceCompany.model.Login;

public class LoginClassMapper implements RowMapper<Login> {

	@Override
	public Login mapRow(ResultSet rs, int rowNum) throws SQLException {
		Login lc = new Login();
		lc.setUserId(rs.getInt(1));
		lc.setUsername(rs.getString(2));
		lc.setPassword(rs.getString(3));
		lc.setRoleid(rs.getInt(4));
		return lc;
	}

}
